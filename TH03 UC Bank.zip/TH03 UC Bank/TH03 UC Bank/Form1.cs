﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_UC_Bank
{
    public partial class Form1 : Form
    {
        public string loginUser;
        public int kolom;
        public int baris;
        public Form1()
        {
            InitializeComponent();
            DataTable rekening = DataRekening.Instance.rekening;
        }

        private void btn_regis_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2(this);
            f2.Show();
            this.Hide();
        }
        private void btn_login_Click(object sender, EventArgs e)
        {
            kolom = 0;
            baris = 0;
            bool exit = true;
            for (int i = 0; i < DataRekening.Instance.rekening.Columns.Count; i++)
            {
                for (int j = 0; j < DataRekening.Instance.rekening.Rows.Count; j++)
                {
                    if (DataRekening.Instance.rekening.Rows[j][i].ToString() == tb_user.Text
                        && DataRekening.Instance.rekening.Rows[j][i + 1].ToString() == tb_pass.Text)
                    {
                        MessageBox.Show("Login Success!");
                        exit = false;
                        loginUser = tb_user.Text;
                        Form3 f3 = new Form3(this);
                        f3.Show();
                        this.Hide();
                    }
                }
                break;
            }
            if (exit == true)
            {
                MessageBox.Show("Username or Password Not Found!");
            }
        }
    }
}
