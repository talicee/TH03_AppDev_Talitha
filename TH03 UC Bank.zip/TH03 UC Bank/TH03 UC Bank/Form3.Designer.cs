﻿namespace TH03_UC_Bank
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_logout = new System.Windows.Forms.Button();
            this.lb_uang = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.lb_ucbank = new System.Windows.Forms.Label();
            this.btn_depo = new System.Windows.Forms.Button();
            this.btn_with = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_logout
            // 
            this.btn_logout.Location = new System.Drawing.Point(287, 99);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(84, 32);
            this.btn_logout.TabIndex = 12;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // lb_uang
            // 
            this.lb_uang.AutoSize = true;
            this.lb_uang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_uang.Location = new System.Drawing.Point(176, 147);
            this.lb_uang.Name = "lb_uang";
            this.lb_uang.Size = new System.Drawing.Size(79, 25);
            this.lb_uang.TabIndex = 9;
            this.lb_uang.Text = "Rp 0,00";
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balance.Location = new System.Drawing.Point(52, 147);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(94, 25);
            this.lb_balance.TabIndex = 8;
            this.lb_balance.Text = "Balance: ";
            // 
            // lb_ucbank
            // 
            this.lb_ucbank.AutoSize = true;
            this.lb_ucbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbank.Location = new System.Drawing.Point(129, 59);
            this.lb_ucbank.Name = "lb_ucbank";
            this.lb_ucbank.Size = new System.Drawing.Size(167, 37);
            this.lb_ucbank.TabIndex = 7;
            this.lb_ucbank.Text = "UC BANK";
            // 
            // btn_depo
            // 
            this.btn_depo.Location = new System.Drawing.Point(171, 202);
            this.btn_depo.Name = "btn_depo";
            this.btn_depo.Size = new System.Drawing.Size(97, 32);
            this.btn_depo.TabIndex = 13;
            this.btn_depo.Text = "Deposit";
            this.btn_depo.UseVisualStyleBackColor = true;
            this.btn_depo.Click += new System.EventHandler(this.btn_depo_Click);
            // 
            // btn_with
            // 
            this.btn_with.Location = new System.Drawing.Point(171, 252);
            this.btn_with.Name = "btn_with";
            this.btn_with.Size = new System.Drawing.Size(97, 32);
            this.btn_with.TabIndex = 14;
            this.btn_with.Text = "Withdraw";
            this.btn_with.UseVisualStyleBackColor = true;
            this.btn_with.Click += new System.EventHandler(this.btn_with_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 450);
            this.Controls.Add(this.btn_with);
            this.Controls.Add(this.btn_depo);
            this.Controls.Add(this.btn_logout);
            this.Controls.Add(this.lb_uang);
            this.Controls.Add(this.lb_balance);
            this.Controls.Add(this.lb_ucbank);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Label lb_uang;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Label lb_ucbank;
        private System.Windows.Forms.Button btn_depo;
        private System.Windows.Forms.Button btn_with;
    }
}