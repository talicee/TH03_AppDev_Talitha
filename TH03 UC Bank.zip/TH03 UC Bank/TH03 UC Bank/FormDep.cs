﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_UC_Bank
{
    public partial class FormDep : Form
    {
        private Form1 f1;
        public FormDep(Form1 form1)
        {
            InitializeComponent();
            this.f1 = form1;
            DataTable rekening = DataRekening.Instance.rekening;
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {           
            int nambah = Convert.ToInt32(tb_deposit.Text);
            if (nambah > 0)
            {
                DataRekening.Instance.rekening.Rows[f1.baris][f1.kolom] = nambah +
                Convert.ToInt32(DataRekening.Instance.rekening.Rows[f1.baris][f1.kolom]);
                MessageBox.Show("Deposit Success !");
            }

            else
            {
                MessageBox.Show("Unable to process! Deposit can't be less than 1 !");
            }
            Form3 f3 = new Form3(f1);
            f3.Show();
            this.Hide();

        }
    }
}
