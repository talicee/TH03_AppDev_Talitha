﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH03_UC_Bank
{
    public class DataRekening
    {
        public DataTable rekening { get; private set; }

        // Singleton pattern
        private static DataRekening instance;

        public static DataRekening Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new DataRekening();
                    instance.Initialize();
                }
                return instance;
            }
        }

        private void Initialize()
        {
            rekening = new DataTable();
            rekening.Columns.Add("Username");
            rekening.Columns.Add("Password");
            rekening.Columns.Add("Balance");
        }

        public void AddRow(string name, string pass, int balance)
        {
            rekening.Rows.Add(name, pass, balance);
        }

    }
}

