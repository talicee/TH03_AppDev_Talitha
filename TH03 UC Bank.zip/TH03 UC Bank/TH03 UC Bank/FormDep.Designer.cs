﻿namespace TH03_UC_Bank
{
    partial class FormDep
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_ucbank = new System.Windows.Forms.Label();
            this.btn_logout = new System.Windows.Forms.Button();
            this.lb_input = new System.Windows.Forms.Label();
            this.tb_deposit = new System.Windows.Forms.TextBox();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_ucbank
            // 
            this.lb_ucbank.AutoSize = true;
            this.lb_ucbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbank.Location = new System.Drawing.Point(131, 74);
            this.lb_ucbank.Name = "lb_ucbank";
            this.lb_ucbank.Size = new System.Drawing.Size(167, 37);
            this.lb_ucbank.TabIndex = 1;
            this.lb_ucbank.Text = "UC BANK";
            // 
            // btn_logout
            // 
            this.btn_logout.Location = new System.Drawing.Point(292, 111);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(84, 32);
            this.btn_logout.TabIndex = 13;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // lb_input
            // 
            this.lb_input.AutoSize = true;
            this.lb_input.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_input.Location = new System.Drawing.Point(116, 162);
            this.lb_input.Name = "lb_input";
            this.lb_input.Size = new System.Drawing.Size(210, 25);
            this.lb_input.TabIndex = 14;
            this.lb_input.Text = "Input Deposit Amount: ";
            // 
            // tb_deposit
            // 
            this.tb_deposit.Location = new System.Drawing.Point(121, 201);
            this.tb_deposit.Name = "tb_deposit";
            this.tb_deposit.Size = new System.Drawing.Size(196, 26);
            this.tb_deposit.TabIndex = 15;
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(173, 244);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(82, 40);
            this.btn_deposit.TabIndex = 16;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // FormDep
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(435, 450);
            this.Controls.Add(this.btn_deposit);
            this.Controls.Add(this.tb_deposit);
            this.Controls.Add(this.lb_input);
            this.Controls.Add(this.btn_logout);
            this.Controls.Add(this.lb_ucbank);
            this.Name = "FormDep";
            this.Text = "FormDep";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_ucbank;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Label lb_input;
        private System.Windows.Forms.TextBox tb_deposit;
        private System.Windows.Forms.Button btn_deposit;
    }
}