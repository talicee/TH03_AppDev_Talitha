﻿namespace TH03_UC_Bank
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_regis_form2 = new System.Windows.Forms.Button();
            this.tb_pass_f2 = new System.Windows.Forms.TextBox();
            this.tb_user_f2 = new System.Windows.Forms.TextBox();
            this.lb_pass2 = new System.Windows.Forms.Label();
            this.lb_user2 = new System.Windows.Forms.Label();
            this.lb_ucbank2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_regis_form2
            // 
            this.btn_regis_form2.Location = new System.Drawing.Point(169, 242);
            this.btn_regis_form2.Name = "btn_regis_form2";
            this.btn_regis_form2.Size = new System.Drawing.Size(84, 32);
            this.btn_regis_form2.TabIndex = 13;
            this.btn_regis_form2.Text = "Register";
            this.btn_regis_form2.UseVisualStyleBackColor = true;
            this.btn_regis_form2.Click += new System.EventHandler(this.btn_regis_form2_Click);
            // 
            // tb_pass_f2
            // 
            this.tb_pass_f2.Location = new System.Drawing.Point(188, 191);
            this.tb_pass_f2.Name = "tb_pass_f2";
            this.tb_pass_f2.Size = new System.Drawing.Size(161, 26);
            this.tb_pass_f2.TabIndex = 11;
            // 
            // tb_user_f2
            // 
            this.tb_user_f2.Location = new System.Drawing.Point(188, 139);
            this.tb_user_f2.Name = "tb_user_f2";
            this.tb_user_f2.Size = new System.Drawing.Size(161, 26);
            this.tb_user_f2.TabIndex = 10;
            // 
            // lb_pass2
            // 
            this.lb_pass2.AutoSize = true;
            this.lb_pass2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_pass2.Location = new System.Drawing.Point(72, 191);
            this.lb_pass2.Name = "lb_pass2";
            this.lb_pass2.Size = new System.Drawing.Size(109, 25);
            this.lb_pass2.TabIndex = 9;
            this.lb_pass2.Text = "Password: ";
            // 
            // lb_user2
            // 
            this.lb_user2.AutoSize = true;
            this.lb_user2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_user2.Location = new System.Drawing.Point(68, 139);
            this.lb_user2.Name = "lb_user2";
            this.lb_user2.Size = new System.Drawing.Size(113, 25);
            this.lb_user2.TabIndex = 8;
            this.lb_user2.Text = "Username: ";
            // 
            // lb_ucbank2
            // 
            this.lb_ucbank2.AutoSize = true;
            this.lb_ucbank2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbank2.Location = new System.Drawing.Point(133, 69);
            this.lb_ucbank2.Name = "lb_ucbank2";
            this.lb_ucbank2.Size = new System.Drawing.Size(167, 37);
            this.lb_ucbank2.TabIndex = 7;
            this.lb_ucbank2.Text = "UC BANK";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 450);
            this.Controls.Add(this.btn_regis_form2);
            this.Controls.Add(this.tb_pass_f2);
            this.Controls.Add(this.tb_user_f2);
            this.Controls.Add(this.lb_pass2);
            this.Controls.Add(this.lb_user2);
            this.Controls.Add(this.lb_ucbank2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_regis_form2;
        private System.Windows.Forms.TextBox tb_pass_f2;
        private System.Windows.Forms.TextBox tb_user_f2;
        private System.Windows.Forms.Label lb_pass2;
        private System.Windows.Forms.Label lb_user2;
        private System.Windows.Forms.Label lb_ucbank2;
    }
}