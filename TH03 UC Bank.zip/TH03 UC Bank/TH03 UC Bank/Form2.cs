﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_UC_Bank
{
    public partial class Form2 : Form
    {
        private Form1 f1;
        public Form2(Form1 form1)
        {
            InitializeComponent();
            this.f1 = form1;
            DataTable rekening = DataRekening.Instance.rekening;
        }      
        
        private void btn_regis_form2_Click(object sender, EventArgs e)
        {
            bool exit = true;
            for (int i = 0; i < DataRekening.Instance.rekening.Columns.Count; i++)
            {
                for (int j = 0; j < DataRekening.Instance.rekening.Rows.Count; j++)
                {
                    if (DataRekening.Instance.rekening.Rows[j][i].ToString() == tb_user_f2.Text)
                    {
                        MessageBox.Show("Username has been used!");
                        tb_user_f2.Text = "";
                        tb_pass_f2.Text = "";
                        exit = false;
                    }
                }
                break;
            }
            if (exit == true)
            {
                DataRekening.Instance.AddRow(tb_user_f2.Text, tb_pass_f2.Text, 0);
                MessageBox.Show("Register Success! ");
                f1.Show();
                this.Hide();
            }

        }
    }
}
