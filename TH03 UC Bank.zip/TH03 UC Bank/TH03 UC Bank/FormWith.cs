﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_UC_Bank
{
    public partial class FormWith : Form
    {
        private Form1 f1;
        public FormWith(Form1 form1)
        {
            InitializeComponent();
            this.f1 = form1;
            DataTable rekening = DataRekening.Instance.rekening;
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            int balance = Convert.ToInt32(DataRekening.Instance.rekening.Rows[f1.baris][f1.kolom]);
            int withdraw = Convert.ToInt32(tb_wtihdraw.Text);

            if (withdraw > balance)
            {
                MessageBox.Show("Unable to process withdrawal ! Not enough balance.");
            }
            else if (withdraw < 1)
            {
                MessageBox.Show("Unable to process! Withdraw can't be less than 1 !");
            }
            else
            {
                DataRekening.Instance.rekening.Rows[f1.baris][f1.kolom] =
                Convert.ToInt32(DataRekening.Instance.rekening.Rows[f1.baris][f1.kolom]) - withdraw;
                MessageBox.Show("Withdrawal Success!");
            }
            Form3 f3 = new Form3(f1);
            f3.Show();
            this.Hide();
        }

        private void FormWith_Load(object sender, EventArgs e)
        {
            CultureInfo culture = new CultureInfo("id-ID");  //[baris][kolom]
            string rupiah = Decimal.Parse(DataRekening.Instance.rekening.Rows[f1.baris][f1.kolom].ToString()).ToString("C", culture);
            lb_uang.Text = rupiah.ToString();          
        }
    }
}
