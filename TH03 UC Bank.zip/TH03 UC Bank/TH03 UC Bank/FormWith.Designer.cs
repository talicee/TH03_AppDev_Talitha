﻿namespace TH03_UC_Bank
{
    partial class FormWith
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.tb_wtihdraw = new System.Windows.Forms.TextBox();
            this.lb_input = new System.Windows.Forms.Label();
            this.btn_logout = new System.Windows.Forms.Button();
            this.lb_ucbank = new System.Windows.Forms.Label();
            this.lb_balancewith = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.lb_uang = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Location = new System.Drawing.Point(172, 290);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(99, 40);
            this.btn_withdraw.TabIndex = 21;
            this.btn_withdraw.Text = "Withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // tb_wtihdraw
            // 
            this.tb_wtihdraw.Location = new System.Drawing.Point(121, 246);
            this.tb_wtihdraw.Name = "tb_wtihdraw";
            this.tb_wtihdraw.Size = new System.Drawing.Size(196, 26);
            this.tb_wtihdraw.TabIndex = 20;
            // 
            // lb_input
            // 
            this.lb_input.AutoSize = true;
            this.lb_input.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_input.Location = new System.Drawing.Point(116, 207);
            this.lb_input.Name = "lb_input";
            this.lb_input.Size = new System.Drawing.Size(226, 25);
            this.lb_input.TabIndex = 19;
            this.lb_input.Text = "Input Withdraw Amount: ";
            // 
            // btn_logout
            // 
            this.btn_logout.Location = new System.Drawing.Point(294, 113);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(84, 32);
            this.btn_logout.TabIndex = 18;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // lb_ucbank
            // 
            this.lb_ucbank.AutoSize = true;
            this.lb_ucbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbank.Location = new System.Drawing.Point(133, 76);
            this.lb_ucbank.Name = "lb_ucbank";
            this.lb_ucbank.Size = new System.Drawing.Size(167, 37);
            this.lb_ucbank.TabIndex = 17;
            this.lb_ucbank.Text = "UC BANK";
            // 
            // lb_balancewith
            // 
            this.lb_balancewith.AutoSize = true;
            this.lb_balancewith.Location = new System.Drawing.Point(67, 163);
            this.lb_balancewith.Name = "lb_balancewith";
            this.lb_balancewith.Size = new System.Drawing.Size(0, 20);
            this.lb_balancewith.TabIndex = 22;
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balance.Location = new System.Drawing.Point(66, 158);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(94, 25);
            this.lb_balance.TabIndex = 23;
            this.lb_balance.Text = "Balance: ";
            // 
            // lb_uang
            // 
            this.lb_uang.AutoSize = true;
            this.lb_uang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_uang.Location = new System.Drawing.Point(179, 158);
            this.lb_uang.Name = "lb_uang";
            this.lb_uang.Size = new System.Drawing.Size(79, 25);
            this.lb_uang.TabIndex = 24;
            this.lb_uang.Text = "Rp 0,00";
            // 
            // FormWith
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 450);
            this.Controls.Add(this.lb_uang);
            this.Controls.Add(this.lb_balance);
            this.Controls.Add(this.lb_balancewith);
            this.Controls.Add(this.btn_withdraw);
            this.Controls.Add(this.tb_wtihdraw);
            this.Controls.Add(this.lb_input);
            this.Controls.Add(this.btn_logout);
            this.Controls.Add(this.lb_ucbank);
            this.Name = "FormWith";
            this.Text = "FormWith";
            this.Load += new System.EventHandler(this.FormWith_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.TextBox tb_wtihdraw;
        private System.Windows.Forms.Label lb_input;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Label lb_ucbank;
        private System.Windows.Forms.Label lb_balancewith;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Label lb_uang;
    }
}