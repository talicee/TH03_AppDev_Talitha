﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_UC_Bank
{  
    public partial class Form3 : Form
    {
        private Form1 f1;
        public Form3(Form1 form1)
        {
            InitializeComponent();
            this.f1 = form1;
            DataTable rekening = DataRekening.Instance.rekening;
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void btn_depo_Click(object sender, EventArgs e)
        {
            FormDep fd = new FormDep(f1);
            fd.Show();
            this.Hide();
        }

        private void btn_with_Click(object sender, EventArgs e)
        {
            FormWith fw = new FormWith(f1);
            fw.Show();
            this.Hide();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < DataRekening.Instance.rekening.Columns.Count; i++)
            {
                for (int j = 0; j < DataRekening.Instance.rekening.Rows.Count; j++)
                {
                    if (DataRekening.Instance.rekening.Rows[j][i].ToString() == f1.loginUser)
                    {
                        CultureInfo culture = new CultureInfo("id-ID");  //[baris][kolom]
                        string rupiah = Decimal.Parse(DataRekening.Instance.rekening.Rows[j][i + 2].ToString()).ToString("C", culture);
                        f1.kolom = i+2;
                        f1.baris = j;
                        lb_uang.Text = rupiah;
                    }
                }
                break;
            }
        }
    }
}
